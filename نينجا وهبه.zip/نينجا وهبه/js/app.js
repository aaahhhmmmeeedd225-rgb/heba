(() => {
  'use strict';

  // ===================== DOM Elements =====================
  const uploadSection   = document.getElementById('uploadSection');
  const editorSection   = document.getElementById('editorSection');
  const progressSection = document.getElementById('progressSection');
  const resultSection   = document.getElementById('resultSection');
  const uploadZone      = document.getElementById('uploadZone');
  const imageInput      = document.getElementById('imageInput');
  const previewCanvas   = document.getElementById('previewCanvas');
  const previewOverlay  = document.getElementById('previewOverlay');
  const generateBtn     = document.getElementById('generateBtn');
  const changeImageBtn  = document.getElementById('changeImageBtn');
  const durationSlider  = document.getElementById('durationSlider');
  const durationValue   = document.getElementById('durationValue');
  const speedSlider     = document.getElementById('speedSlider');
  const speedValue      = document.getElementById('speedValue');
  const progressFill    = document.getElementById('progressFill');
  const progressPercent = document.getElementById('progressPercent');
  const progressText    = document.getElementById('progressText');
  const resultVideo     = document.getElementById('resultVideo');
  const downloadBtn     = document.getElementById('downloadBtn');
  const newVideoBtn     = document.getElementById('newVideoBtn');

  // ===================== State =====================
  let sourceImage     = null;
  let selectedMotion  = 'zoom-in';
  let duration        = 5;
  let speed           = 2;
  let mediaRecorder   = null;
  let recordedChunks  = [];
  let currentBlobUrl  = null;
  let isGenerating    = false;

  const speedLabels = { 1: 'بطيء', 2: 'متوسط', 3: 'سريع' };

  // ===================== Upload Handlers =====================
  uploadZone.addEventListener('click', () => {
    if (!isGenerating) imageInput.click();
  });

  uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.classList.add('dragover');
  });

  uploadZone.addEventListener('dragleave', () => {
    uploadZone.classList.remove('dragover');
  });

  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    if (isGenerating) return;
    const file = e.dataTransfer.files && e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      loadImage(file);
    }
  });

  imageInput.addEventListener('change', (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) loadImage(file);
  });

  function loadImage(file) {
    if (!file || !file.type.startsWith('image/')) {
      alert('من فضلك اختر صورة صحيحة');
      return;
    }

    // Limit size roughly (avoid huge images crashing mobile)
    if (file.size > 15 * 1024 * 1024) {
      alert('الصورة كبيرة جداً. اختار صورة أصغر من 15 ميجا');
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => alert('حصل خطأ أثناء قراءة الصورة');
    reader.onload = (ev) => {
      const img = new Image();
      img.onerror = () => alert('الصورة مش مدعومة أو تالفة');
      img.onload = () => {
        sourceImage = img;
        showEditor();
        drawPreview();
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  }

  // ===================== UI Helpers =====================
  function hideAll() {
    uploadSection.classList.add('hidden');
    editorSection.classList.add('hidden');
    progressSection.classList.add('hidden');
    resultSection.classList.add('hidden');
  }

  function showEditor() {
    hideAll();
    editorSection.classList.remove('hidden');
    previewOverlay.classList.remove('hide');
  }

  function showProgress() {
    hideAll();
    progressSection.classList.remove('hidden');
    progressFill.style.width = '0%';
    progressPercent.textContent = '0%';
    progressText.textContent = 'جاري إنشاء الفيديو...';
  }

  function showResult(blobUrl) {
    hideAll();
    resultSection.classList.remove('hidden');

    if (currentBlobUrl) {
      try { URL.revokeObjectURL(currentBlobUrl); } catch (_) {}
    }
    currentBlobUrl = blobUrl;

    resultVideo.src = blobUrl;
    resultVideo.load();
    downloadBtn.href = blobUrl;
    downloadBtn.download = 'ninja-ai-video.webm';

    resultVideo.play().catch(() => {});
  }

  function resetToUpload() {
    if (isGenerating) return;
    sourceImage = null;
    imageInput.value = '';
    resultVideo.removeAttribute('src');
    resultVideo.load();

    if (currentBlobUrl) {
      try { URL.revokeObjectURL(currentBlobUrl); } catch (_) {}
      currentBlobUrl = null;
    }

    hideAll();
    uploadSection.classList.remove('hidden');
  }

  // ===================== Controls =====================
  document.querySelectorAll('.motion-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (isGenerating) return;
      document.querySelectorAll('.motion-btn').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      selectedMotion = btn.dataset.motion || 'zoom-in';
      drawPreview();
    });
  });

  durationSlider.addEventListener('input', () => {
    duration = parseInt(durationSlider.value, 10) || 5;
    durationValue.textContent = String(duration);
  });

  speedSlider.addEventListener('input', () => {
    speed = parseInt(speedSlider.value, 10) || 2;
    speedValue.textContent = speedLabels[speed] || 'متوسط';
  });

  changeImageBtn.addEventListener('click', resetToUpload);
  newVideoBtn.addEventListener('click', resetToUpload);
  generateBtn.addEventListener('click', () => {
    if (!isGenerating) startGeneration();
  });

  // ===================== Preview Drawing =====================
  function getMotionLabel(m) {
    const map = {
      'zoom-in':   'تكبير',
      'zoom-out':  'تصغير',
      'pan-left':  'تحريك يمين',
      'pan-right': 'تحريك شمال',
      'kenburns':  'كين بيرنز'
    };
    return map[m] || m;
  }

  function drawPreview() {
    if (!sourceImage) return;

    const canvas = previewCanvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const targetW = 720;
    const targetH = 1280;
    canvas.width  = targetW;
    canvas.height = targetH;

    const scale  = Math.max(targetW / sourceImage.width, targetH / sourceImage.height);
    const drawW  = sourceImage.width  * scale;
    const drawH  = sourceImage.height * scale;
    const offsetX = (targetW - drawW) / 2;
    const offsetY = (targetH - drawH) / 2;

    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, targetW, targetH);
    ctx.drawImage(sourceImage, offsetX, offsetY, drawW, drawH);

    const label = previewOverlay.querySelector('span');
    if (label) {
      label.textContent = 'جاهز • ' + getMotionLabel(selectedMotion);
    }
  }

  // ===================== Video Generation =====================
  async function startGeneration() {
    if (!sourceImage || isGenerating) return;

    isGenerating = true;
    generateBtn.disabled = true;
    showProgress();
    recordedChunks = [];

    const fps         = 30;
    const totalFrames = Math.max(1, duration * fps);
    const outW        = 720;
    const outH        = 1280;

    const canvas = document.createElement('canvas');
    canvas.width  = outW;
    canvas.height = outH;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      alert('المتصفح مش بيدعم الرسم على Canvas');
      isGenerating = false;
      generateBtn.disabled = false;
      showEditor();
      return;
    }

    // Cover scale of original image
    const baseScale = Math.max(outW / sourceImage.width, outH / sourceImage.height);
    const baseW     = sourceImage.width  * baseScale;
    const baseH     = sourceImage.height * baseScale;
    const intensity = speed * 0.08;

    let stream;
    try {
      stream = canvas.captureStream(fps);
    } catch (err) {
      alert('المتصفح مش بيدعم تسجيل الفيديو من Canvas');
      isGenerating = false;
      generateBtn.disabled = false;
      showEditor();
      return;
    }

    // Choose best supported mime type
    const candidates = [
      'video/webm;codecs=vp9',
      'video/webm;codecs=vp8',
      'video/webm',
      'video/mp4'
    ];
    let mimeType = '';
    for (const t of candidates) {
      if (MediaRecorder.isTypeSupported(t)) {
        mimeType = t;
        break;
      }
    }

    try {
      mediaRecorder = mimeType
        ? new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 3500000 })
        : new MediaRecorder(stream);
    } catch (err) {
      alert('حصل خطأ في بدء تسجيل الفيديو');
      isGenerating = false;
      generateBtn.disabled = false;
      showEditor();
      return;
    }

    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    const recordingDone = new Promise((resolve) => {
      mediaRecorder.onstop = () => resolve();
      mediaRecorder.onerror = () => resolve();
    });

    try {
      mediaRecorder.start(100);
    } catch (err) {
      alert('فشل بدء التسجيل');
      isGenerating = false;
      generateBtn.disabled = false;
      showEditor();
      return;
    }

    // Render frames
    try {
      for (let frame = 0; frame <= totalFrames; frame++) {
        const t    = frame / totalFrames;
        const ease = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

        let scale   = 1;
        let offsetX = 0;
        let offsetY = 0;

        switch (selectedMotion) {
          case 'zoom-in':
            scale = 1 + ease * intensity * 2.2;
            break;
          case 'zoom-out':
            scale = 1 + (1 - ease) * intensity * 2.2;
            break;
          case 'pan-left':
            scale   = 1.15;
            offsetX = -ease * (baseW * 0.18);
            break;
          case 'pan-right':
            scale   = 1.15;
            offsetX = ease * (baseW * 0.18);
            break;
          case 'kenburns':
          default:
            scale   = 1 + ease * intensity * 1.8;
            offsetX = (ease - 0.5) * baseW * 0.12;
            offsetY = (0.5 - ease) * baseH * 0.08;
            break;
        }

        const drawW = baseW * scale;
        const drawH = baseH * scale;
        const x     = (outW - drawW) / 2 + offsetX;
        const y     = (outH - drawH) / 2 + offsetY;

        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, outW, outH);
        ctx.drawImage(sourceImage, x, y, drawW, drawH);

        const pct = Math.round((frame / totalFrames) * 100);
        progressFill.style.width = pct + '%';
        progressPercent.textContent = pct + '%';

        // Yield so UI stays responsive
        await new Promise((r) => setTimeout(r, 1000 / fps));
      }
    } catch (err) {
      console.error(err);
      alert('حصل خطأ أثناء إنشاء الفيديو');
      isGenerating = false;
      generateBtn.disabled = false;
      showEditor();
      return;
    }

    // Stop recording
    try {
      if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
      }
    } catch (_) {}

    await recordingDone;

    // Build final blob
    if (recordedChunks.length === 0) {
      alert('مفيش بيانات فيديو. جرب متصفح تاني (Chrome أفضل)');
      isGenerating = false;
      generateBtn.disabled = false;
      showEditor();
      return;
    }

    const blobType = (mediaRecorder && mediaRecorder.mimeType) || 'video/webm';
    const blob = new Blob(recordedChunks, { type: blobType });
    const url  = URL.createObjectURL(blob);

    isGenerating = false;
    generateBtn.disabled = false;
    showResult(url);
  }

  // ===================== Init =====================
  // Safety: make sure all critical elements exist
  if (!uploadZone || !imageInput || !generateBtn) {
    console.error('Ninja AI: missing critical DOM elements');
  }
})();
